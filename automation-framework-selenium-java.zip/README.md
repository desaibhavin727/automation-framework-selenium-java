# Selenium Automation Framework

This project demonstrates a simple automation framework using:

- Java
- Selenium WebDriver
- TestNG
- Maven
- Page Object Model

## Run Tests

mvn clean test

## Author

Bhavin Desai
QA Automation Engineer
